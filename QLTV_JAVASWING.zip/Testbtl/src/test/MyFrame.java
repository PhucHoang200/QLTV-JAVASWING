package test;

import javax.swing.*;
import java.awt.*;

public class MyFrame extends JFrame {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MyFrame() {
        setTitle("Resizable JFrame Example");
        setSize(365, 262); // Initial size
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center on screen

        // Use BorderLayout for JFrame
        getContentPane().setLayout(new BorderLayout());

        // Create a JPanel with some components
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout()); // Set layout manager for JPanel

        // Add some components to JPanel
        JButton button1 = new JButton("Button 1");
        JButton button2 = new JButton("Button 2");
        JTextArea textArea = new JTextArea();

        panel.add(button1, BorderLayout.NORTH);
        panel.add(button2, BorderLayout.SOUTH);
        panel.add(new JScrollPane(textArea), BorderLayout.CENTER);

        // Add JPanel to JFrame
        getContentPane().add(panel, BorderLayout.CENTER);

        // Pack and set visible
        pack();
        setVisible(true);
        setResizable(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MyFrame());
    }
}
