package test;

import javax.swing.JPanel;

public class test1 extends JPanel {

	private static final long serialVersionUID = 1L;

	/**
	 * Create the panel.
	 */
	public test1() {

	}

}
