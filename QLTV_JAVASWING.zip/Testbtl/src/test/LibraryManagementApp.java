package test;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class LibraryManagementApp extends JFrame {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel panelLeft;
    private JPanel panelRight;
    private CardLayout cardLayout;

    public LibraryManagementApp() {
        setTitle("Library Management System");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create left panel with options
        panelLeft = new JPanel();
        panelLeft.setLayout(new BoxLayout(panelLeft, BoxLayout.Y_AXIS));

        JButton btnBooks = new JButton("Books");
        JButton btnMembers = new JButton("Members");
        JButton btnLoans = new JButton("Loans");

        panelLeft.add(btnBooks);
        panelLeft.add(btnMembers);
        panelLeft.add(btnLoans);

        // Create right panel with card layout to switch between different views
        cardLayout = new CardLayout();
        panelRight = new JPanel(cardLayout);

        JPanel booksPanel = new JPanel();
        booksPanel.add(new JLabel("Books Information"));
        
        JPanel membersPanel = new JPanel();
        membersPanel.add(new JLabel("Members Information"));
        
        JPanel loansPanel = new JPanel();
        loansPanel.add(new JLabel("Loans Information"));

        panelRight.add(booksPanel, "Books");
        panelRight.add(membersPanel, "Members");
        panelRight.add(loansPanel, "Loans");

        // Add event listeners for buttons
        btnBooks.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                cardLayout.show(panelRight, "Books");
            }
        });

        btnMembers.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                cardLayout.show(panelRight, "Members");
            }
        });

        btnLoans.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                cardLayout.show(panelRight, "Loans");
            }
        });

        // Use JSplitPane to split the window
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, panelLeft, panelRight);
        splitPane.setDividerLocation(150);

        add(splitPane);

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(LibraryManagementApp::new);
    }
}
