package com.librarymanagement.views;

import com.librarymanagement.controllers.BorrowingController;
import com.toedter.calendar.JDateChooser;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class BorrowingFrame extends JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField txtBorrowingID;
    private JComboBox<String> cmbBookID;
    private JComboBox<String> cmbReaderID;
    private JDateChooser dateChooserBorrow;
    private JDateChooser dateChooserReturn;
    private JSpinner spinnerQuantity;
    private JTable tableBorrowings;
    private BorrowingController controller;

    public static void main(String[] args) {
		BorrowingFrame borrowingFrame = new BorrowingFrame();
		borrowingFrame.setDefaultCloseOperation(EXIT_ON_CLOSE);
		borrowingFrame.setVisible(true);
	}
    public BorrowingFrame() {
        setTitle("Quản lý phiếu mượn");
        setBounds(100, 100, 800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        controller = new BorrowingController();

        JLabel lblTitle = new JLabel("Quản lý phiếu mượn");
        lblTitle.setFont(new Font("Tahoma", Font.PLAIN, 24));
        lblTitle.setBounds(10, 10, 764, 30);
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        getContentPane().add(lblTitle);

        JLabel lblBorrowingID = new JLabel("Mã phiếu mượn");
        lblBorrowingID.setBounds(20, 60, 120, 30);
        getContentPane().add(lblBorrowingID);

        txtBorrowingID = new JTextField();
        txtBorrowingID.setBounds(150, 60, 200, 30);
        txtBorrowingID.setEditable(false);
        getContentPane().add(txtBorrowingID);

        JLabel lblBookID = new JLabel("Mã sách");
        lblBookID.setBounds(20, 100, 120, 30);
        getContentPane().add(lblBookID);

        cmbBookID = new JComboBox<>();
        cmbBookID.setBounds(150, 100, 200, 30);
        getContentPane().add(cmbBookID);

        JLabel lblReaderID = new JLabel("Mã độc giả");
        lblReaderID.setBounds(20, 140, 120, 30);
        getContentPane().add(lblReaderID);

        cmbReaderID = new JComboBox<>();
        cmbReaderID.setBounds(150, 140, 200, 30);
        getContentPane().add(cmbReaderID);

        JLabel lblBorrowDate = new JLabel("Ngày mượn");
        lblBorrowDate.setBounds(20, 180, 120, 30);
        getContentPane().add(lblBorrowDate);

        dateChooserBorrow = new JDateChooser();
        dateChooserBorrow.setBounds(150, 180, 200, 30);
        getContentPane().add(dateChooserBorrow);

        JLabel lblReturnDate = new JLabel("Ngày trả dự kiến");
        lblReturnDate.setBounds(20, 220, 120, 30);
        getContentPane().add(lblReturnDate);

        dateChooserReturn = new JDateChooser();
        dateChooserReturn.setBounds(150, 220, 200, 30);
        getContentPane().add(dateChooserReturn);

        JLabel lblQuantity = new JLabel("Số lượng");
        lblQuantity.setBounds(20, 260, 120, 30);
        getContentPane().add(lblQuantity);

        spinnerQuantity = new JSpinner(new SpinnerNumberModel(1, 1, 5, 1));
        spinnerQuantity.setBounds(150, 260, 200, 30);
        getContentPane().add(spinnerQuantity);

        JButton btnAdd = new JButton("Thêm");
        btnAdd.setBounds(400, 60, 120, 30);
        getContentPane().add(btnAdd);
        btnAdd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addBorrowing();
            }
        });

        JButton btnEdit = new JButton("Sửa");
        btnEdit.setBounds(400, 100, 120, 30);
        getContentPane().add(btnEdit);
        btnEdit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editBorrowing();
            }
        });

        JButton btnDelete = new JButton("Xóa");
        btnDelete.setBounds(400, 140, 120, 30);
        getContentPane().add(btnDelete);
        btnDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteBorrowing();
            }
        });

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(20, 300, 740, 250);
        getContentPane().add(scrollPane);

        tableBorrowings = new JTable();
        scrollPane.setViewportView(tableBorrowings);

        loadBookIDs();
        loadReaderIDs();
        loadBorrowings();
    }

    private void loadBookIDs() {
        try {
            String[] bookIDs = controller.getBookIDs();
            for (String bookID : bookIDs) {
                cmbBookID.addItem(bookID);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Lỗi tải mã sách: " + e.getMessage());
        }
    }

    private void loadReaderIDs() {
        try {
            String[] readerIDs = controller.getReaderIDs();
            for (String readerID : readerIDs) {
                cmbReaderID.addItem(readerID);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Lỗi tải mã độc giả: " + e.getMessage());
        }
    }

    private void loadBorrowings() {
        try {
            tableBorrowings.setModel(controller.getBorrowingsTableModel());
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Lỗi tải phiếu mượn: " + e.getMessage());
        }
    }

    private void addBorrowing() {
        try {
            String bookID = (String) cmbBookID.getSelectedItem();
            String readerID = (String) cmbReaderID.getSelectedItem();
            Date borrowDate = dateChooserBorrow.getDate();
            Date returnDate = dateChooserReturn.getDate();
            int quantity = (int) spinnerQuantity.getValue();

            if (borrowDate != null && returnDate != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String formattedBorrowDate = sdf.format(borrowDate);
                String formattedReturnDate = sdf.format(returnDate);

                controller.addBorrowing(bookID, readerID, formattedBorrowDate, formattedReturnDate, quantity);
                loadBorrowings();
            } else {
                JOptionPane.showMessageDialog(this, "Ngày mượn và ngày trả dự kiến không được để trống.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Lỗi thêm phiếu mượn: " + e.getMessage());
        }
    }

    private void editBorrowing() {
        try {
            int selectedRow = tableBorrowings.getSelectedRow();
            if (selectedRow != -1) {
                String borrowingID = tableBorrowings.getValueAt(selectedRow, 0).toString();
                String bookID = (String) cmbBookID.getSelectedItem();
                String readerID = (String) cmbReaderID.getSelectedItem();
                Date borrowDate = dateChooserBorrow.getDate();
                Date returnDate = dateChooserReturn.getDate();
                int quantity = (int) spinnerQuantity.getValue();

                if (borrowDate != null && returnDate != null) {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    String formattedBorrowDate = sdf.format(borrowDate);
                    String formattedReturnDate = sdf.format(returnDate);

                    controller.updateBorrowing(borrowingID, bookID, readerID, formattedBorrowDate, formattedReturnDate, quantity);
                    loadBorrowings();
                } else {
                    JOptionPane.showMessageDialog(this, "Ngày mượn và ngày trả dự kiến không được để trống.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Chọn một hàng để sửa.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Lỗi sửa phiếu mượn: " + e.getMessage());
        }
    }

    private void deleteBorrowing() {
        try {
            int selectedRow = tableBorrowings.getSelectedRow();
            if (selectedRow != -1) {
                String borrowingID = tableBorrowings.getValueAt(selectedRow, 0).toString();
                controller.deleteBorrowing(borrowingID);
                loadBorrowings();
            } else {
                JOptionPane.showMessageDialog(this, "Chọn một hàng để xóa.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Lỗi xóa phiếu mượn: " + e.getMessage());
        }
    }
}
