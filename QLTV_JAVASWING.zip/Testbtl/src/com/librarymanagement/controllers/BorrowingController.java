package com.librarymanagement.controllers;

import com.librarymanagement.helpers.DatabaseHelper;

import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class BorrowingController {

    public String[] getBookIDs() throws SQLException {
        return DatabaseHelper.getColumnValues("Sach", "MaSach");
    }

    public String[] getReaderIDs() throws SQLException {
        return DatabaseHelper.getColumnValues("DocGia", "MaDocGia");
    }

    public DefaultTableModel getBorrowingsTableModel() throws SQLException {
        String query = "SELECT * FROM PhieuMuon";
        ResultSet rs = DatabaseHelper.executeQuery(query);
        return DatabaseHelper.resultSetToTableModel(rs);
    }

    public void addBorrowing(String bookID, String readerID, String borrowDate, String returnDate, int quantity) throws SQLException {
        String query = "INSERT INTO PhieuMuon (MaSach, MaDocGia, NgayMuon, NgayTraDuKien, SoLuong) VALUES ('"
                + bookID + "', '" + readerID + "', '" + borrowDate + "', '" + returnDate + "', " + quantity + ")";
        DatabaseHelper.executeUpdate(query);
    }

    public void updateBorrowing(String borrowingID, String bookID, String readerID, String borrowDate, String returnDate, int quantity) throws SQLException {
        String query = "UPDATE PhieuMuon SET MaSach = '" + bookID + "', MaDocGia = '" + readerID + "', NgayMuon = '"
                + borrowDate + "', NgayTraDuKien = '" + returnDate + "', SoLuong = " + quantity + " WHERE MaPhieuMuon = '" + borrowingID + "'";
        DatabaseHelper.executeUpdate(query);
    }

    public void deleteBorrowing(String borrowingID) throws SQLException {
        String query = "DELETE FROM PhieuMuon WHERE MaPhieuMuon = '" + borrowingID + "'";
        DatabaseHelper.executeUpdate(query);
    }
}
