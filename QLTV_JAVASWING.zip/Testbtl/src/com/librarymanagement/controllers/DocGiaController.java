package com.librarymanagement.controllers;

import com.librarymanagement.models.DocGia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class DocGiaController {
    private static final String connUrl = "jdbc:sqlserver://LAPTOP-VI7NDRKV:1433;" +
            "user=sa;password=123456789;databaseName=QLTVTEST;encrypt=false";

    public static void checkConnection(JTable table) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0); // Xóa các dòng cũ trong table
        
        String sql = "SELECT * FROM DocGia";
        try (Connection conn = DriverManager.getConnection(connUrl);
             Statement statement = conn.createStatement();
             ResultSet rs = statement.executeQuery(sql)) {
            while (rs.next()) {
                Object[] row = new Object[7];
                for (int i = 0; i < 7; i++) {
                    row[i] = rs.getObject(i + 1);
                }
                model.addRow(row);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Lỗi khi lấy dữ liệu từ cơ sở dữ liệu: " + e.getMessage());
        }
    }


    public void addDocGia(DocGia docGia) {
        String sql = "INSERT INTO DocGia (MaDocGia, HoTen, CCCD, NgaySinh, GioiTinh, DiaChi, SDT) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DriverManager.getConnection(connUrl);
             PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setString(1, docGia.getMaDocGia());
            statement.setString(2, docGia.getTenDocGia());
            statement.setString(3, docGia.getCccd());
            statement.setDate(4, docGia.getNgaySinh());
            statement.setString(5, docGia.getGioiTinh());
            statement.setString(6, docGia.getDiaChi());
            statement.setString(7, docGia.getSdt());

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new DocGia was inserted successfully!");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Lỗi khi thêm độc giả: " + e.getMessage());
        }	
    }

    public void updateDocGia(int selectedRow, DocGia docGia) {
        String sql = "UPDATE DocGia SET HoTen=?, CCCD=?, NgaySinh=?, GioiTinh=?, DiaChi=?, SDT=? WHERE MaDocGia=?";
        
        try (Connection conn = DriverManager.getConnection(connUrl);
             PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setString(1, docGia.getTenDocGia());
            statement.setString(2, docGia.getCccd());
            statement.setDate(3, docGia.getNgaySinh());
            statement.setString(4, docGia.getGioiTinh());
            statement.setString(5, docGia.getDiaChi());
            statement.setString(6, docGia.getSdt());
            statement.setString(7, docGia.getMaDocGia());

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("DocGia was updated successfully!");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Lỗi khi cập nhật độc giả: " + e.getMessage());
        }
    }


    public void deleteDocGia(int selectedRow, JTable table) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        String maDocGia = (String) model.getValueAt(selectedRow, 0);

        String sql = "DELETE FROM DocGia WHERE MaDocGia=?";
        
        try (Connection conn = DriverManager.getConnection(connUrl);
             PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setString(1, maDocGia);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("A DocGia was deleted successfully!");
                model.removeRow(selectedRow); // Remove the row from the table model
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Lỗi khi xóa độc giả: " + e.getMessage());
        }
    }

    public void searchDocGia(String keyword, JTable table) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0); // Clear existing rows

        String sql = "SELECT * FROM DocGia WHERE MaDocGia LIKE ? OR HoTen LIKE ? OR CCCD LIKE ? OR DiaChi LIKE ? OR SDT LIKE ? OR GioiTinh LIKE ? OR NgaySinh LIKE ? ";
        try (Connection conn = DriverManager.getConnection(connUrl);
             PreparedStatement statement = conn.prepareStatement(sql)) {
            String searchKeyword = "%" + keyword + "%";
            for (int i = 1; i <= 7; i++) {
                statement.setString(i, searchKeyword);
            }

            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    Object[] row = new Object[7];
                    for (int i = 0; i < 7; i++) {
                        row[i] = rs.getObject(i + 1);
                    }
                    model.addRow(row);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Lỗi khi tìm kiếm độc giả: " + e.getMessage());
        }
    }

}
