package com.librarymanagement.helpers;

import javax.swing.table.DefaultTableModel;
import java.sql.*;

public class DatabaseHelper {

    private static final String connUrl = "jdbc:sqlserver://LAPTOP-VI7NDRKV:1433;user=sa;password=123456789;databaseName=QLTVTEST;encrypt=false";

    private static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(connUrl);
    }

    public static String[] getColumnValues(String tableName, String columnName) throws SQLException {
        try (Connection connection = getConnection();
             Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery("SELECT " + columnName + " FROM " + tableName)) {

            rs.last();
            int rowCount = rs.getRow();
            rs.beforeFirst();

            String[] values = new String[rowCount];
            int i = 0;
            while (rs.next()) {
                values[i++] = rs.getString(columnName);
            }
            return values;
        }
    }

    public static ResultSet executeQuery(String query) throws SQLException {
        Connection connection = getConnection();
        Statement statement = connection.createStatement();
        return statement.executeQuery(query);
    }

    public static void executeUpdate(String query) throws SQLException {
        try (Connection connection = getConnection();
             Statement statement = connection.createStatement()) {
            statement.executeUpdate(query);
        }
    }

    public static DefaultTableModel resultSetToTableModel(ResultSet rs) throws SQLException {
        ResultSetMetaData metaData = rs.getMetaData();
        int columnCount = metaData.getColumnCount();

        String[] columnNames = new String[columnCount];
        for (int i = 0; i < columnCount; i++) {
            columnNames[i] = metaData.getColumnName(i + 1);
        }

        DefaultTableModel model = new DefaultTableModel(columnNames, 0);

        while (rs.next()) {
            Object[] rowData = new Object[columnCount];
            for (int i = 0; i < columnCount; i++) {
                rowData[i] = rs.getObject(i + 1);
            }
            model.addRow(rowData);
        }
        return model;
    }

    public static void fillTableModel(DefaultTableModel model, String sql) throws SQLException {
        try (Connection connection = getConnection();
             Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery(sql)) {

            model.setRowCount(0);
            while (rs.next()) {
                Object[] row = new Object[model.getColumnCount()];
                for (int i = 0; i < model.getColumnCount(); i++) {
                    row[i] = rs.getObject(i + 1);
                }
                model.addRow(row);
            }
        }
    }

    public static void fillTableModel(DefaultTableModel model, String sql, String[] params) throws SQLException {
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            for (int i = 0; i < params.length; i++) {
                statement.setString(i + 1, params[i]);
            }

            try (ResultSet rs = statement.executeQuery()) {
                model.setRowCount(0);
                while (rs.next()) {
                    Object[] row = new Object[model.getColumnCount()];
                    for (int i = 0; i < model.getColumnCount(); i++) {
                        row[i] = rs.getObject(i + 1);
                    }
                    model.addRow(row);
                }
            }
        }
    }
}
